package hr.fer.zemris.fuzzy;

public interface IIntUnaryFunction {

    double valueAt(int index);

}

